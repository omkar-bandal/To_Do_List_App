import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import TodoForm from './TodoForm';
import TodoLists from './TodoLists';
function App() {

  const [todos, setTodos] = useState([]);

  const addTodo = (newTodo) => {
    // const newTodo = {
    //   id: Date.now(),
    //   taskdate,
    //   title,
    //   description,
    //   completed: false,
    // };

    setTodos((prevTodos) => [...prevTodos, newTodo]);
  };

  const toggleComplete = (id) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
  };

  const [isVisible, setIsVisible] = useState(false);
  const toggleToDoForm = () => {
    setIsVisible(!isVisible);
  };

  return (
    <>
      <div class="container-fluid">
        <h1 class="display-4 text-center text-light my-3">To Do List</h1>
        <button class="btn btn-outline-light d-block mx-auto my-2"
          onClick={toggleToDoForm}>Create Task</button>
        {isVisible && <TodoForm addTodo={addTodo} />}
      </div>
      <div className="container-sm my-3">
        <TodoLists
          todos={todos}
          toggleComplete={toggleComplete}
          deleteTodo={deleteTodo}
        />
      </div>
    </>
  );
}
export default App;
