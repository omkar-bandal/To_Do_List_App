import React, { useState } from 'react'
import './TodoForm.css'
export default function TodoForm({ addTodo }) {
    const [taskdate, setTaskdate] = useState('');
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;

        if (name === 'taskdate') {
            setTaskdate(value);
        } else if (name === 'title') {
            setTitle(value);
        } else if (name === 'description') {
            setDescription(value);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (taskdate.trim() === '' || title.trim() === '' || description.trim() === '') {
            return;
        }

        const newTodo = {
            id: Date.now(),
            taskdate,
            title,
            description,
            completed: false,
        };

        addTodo(newTodo);

        setTaskdate('');
        setTitle('');
        setDescription('');
    };

    return (
        <>
            <div class='container-sm mx-5 p-3 addtaskblock'>
                <form class="row" onSubmit={handleSubmit}>
                    <div class="col-sm-10">
                        <div class="row">
                            <div class="col-sm-3">
                                <label for="date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="date"
                                    name='taskdate' value={taskdate} onChange={handleChange} />
                            </div>
                            <div class="col-sm-4">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" id="title"
                                    name='title' value={title} onChange={handleChange} />
                            </div>
                            <div class="col-sm-5">
                                <label for="desc" class="form-label">Description</label>
                                <input type="text" class="form-control" id="desc"
                                    name='description' value={description} onChange={handleChange} />
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <button type="submit" class="btn btn-outline-light d-block mx-auto">Add Task</button>
                    </div>
                </form>
            </div>
        </>
    )
}
