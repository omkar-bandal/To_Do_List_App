import React from 'react'
import './TodoListItems.css'
export default function TodoListItems({ todo, toggleComplete, deleteTodo }) {
    return (
        <>
            {/* <li>
                <div class='container-sm d-flex flex-row justify-content-around align-items-center mx-auto p-3 addtaskblock'>
                    <input

                        type="checkbox"
                        checked={todo.completed}
                        onChange={() => toggleComplete(todo.id)}
                    />
                    <span class=''>{todo.taskdate}</span>
                    <span class=''>{todo.title}</span>
                    <span class=''>{todo.description}</span>
                    <button class='btn btn-outline-light' onClick={() => deleteTodo(todo.id)}>Delete</button>
                </div>
            </li> */}
            <tr class='text-center'>
                <th><input type="checkbox" checked={todo.completed} onChange={() => toggleComplete(todo.id)} /></th>
                <td>{todo.taskdate}</td>
                <td>{todo.title}</td>
                <td>{todo.description}</td>
                <td> <button class='btn btn-outline-light mb-4'
                    onClick={() => deleteTodo(todo.id)}>Delete
                </button></td>
            </tr>
        </>
    );
}

