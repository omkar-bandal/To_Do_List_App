import React from 'react';
import TodoListItems from './TodoListItems';
export default function TodoLists({ todos, toggleComplete, deleteTodo }) {
    return (
        <>
            {/* <ul>
                {todos.map(todo => (
                    <TodoListItems
                        key={todo.id}
                        todo={todo}
                        toggleComplete={toggleComplete}
                        deleteTodo={deleteTodo}
                    />
                ))}
            </ul> */}
            <table class="table table-dark table-hover align-middle">
                <thead class='text-center'>
                    <tr>
                        <th scope="col">Complete</th>
                        <th scope="col">Date</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Option</th>
                    </tr>
                </thead>
                <tbody class='table-group-divider'>
                {todos.map(todo => (
                    <TodoListItems
                        key={todo.id}
                        todo={todo}
                        toggleComplete={toggleComplete}
                        deleteTodo={deleteTodo}
                    />
                ))}
                </tbody>
            </table>
        </>
    )
}
